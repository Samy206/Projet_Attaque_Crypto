# IN603 - DM : PRESENT24 

## BOUMALI Samy - LYONNET Clément

### Dépendances
	make, gcc, tar, rsync

### Compilation
	make compile
	
### Exécution
	make
	
### Nettoyage
	make clean
	
### Archivage
	make tar
	
#### Données utilisées
(m1,c1) = (684d0f, 66fb2e) (m2,c2) = (db4819,75d43b) BOUMALI
Résultats : (ce5d2f,564a66)(92dce7,ecd4e7)(a4cc1b,d511f5)
